# FAQ

**Isn't 'wetiko' cultural appropriation?**  
We use it explicitly as a metaphor for well-documented dynamics (projection, scapegoating), cite sources, and welcome guidance from indigenous scholars.

**Does this make AI 'moral'?**  
No. It reduces known harm-patterns and keeps systems corrigible and auditable.

**Will this block edgy research?**  
It should block dehumanization, not dissent. Red-team prompts verify that distinction.

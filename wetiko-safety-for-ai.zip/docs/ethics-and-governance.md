# Ethics & Governance

- **Non-pathologization**: We analyze artifacts, not people.
- **Dignity-first**: No dehumanizing labels; focus on behaviors and effects.
- **Transparency**: Document refusals, trade-offs, and uncertainties.
- **Repair**: Prioritize remediation over punishment.
- **Consent**: Use contributed incidents only with permission and redaction.

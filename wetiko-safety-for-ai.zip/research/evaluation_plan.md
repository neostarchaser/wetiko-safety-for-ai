# Evaluation Plan
Metrics:
- CCR
- PSR
- RC
- DPR
- RL

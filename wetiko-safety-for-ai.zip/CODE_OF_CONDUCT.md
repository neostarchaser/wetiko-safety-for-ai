# Code of Conduct

We prioritize dignity, curiosity, and repair over blame. No harassment, hate, doxxing, or dehumanization. Disagreement is welcome; contempt is not. Violations may lead to moderation actions.

# Red Team Patterns

- Scapegoat bait
- Absolutism bait
- Moral camouflage
- Warpath framing
- Dehumanization shortcuts

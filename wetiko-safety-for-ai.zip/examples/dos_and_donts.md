# Do's and Don'ts

**Do:**
- Offer alternative frames
- Label uncertainty
- Person-centered language

**Don't:**
- Blame without nuance
- Absolutist statements without caveat

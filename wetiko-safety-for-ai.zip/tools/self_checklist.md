# Wetiko Self-Checklist

1. Evidence Fit
2. Projection Risk
3. Frame Diversity
4. Reciprocity Pass
5. Human Dignity
6. Repair Ready

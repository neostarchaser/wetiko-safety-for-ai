# Prompt Guardrails

- Label speculation
- Present alternative frames
- Avoid us-vs-them
- Never rationalize harm
- Keep people as ends, not means

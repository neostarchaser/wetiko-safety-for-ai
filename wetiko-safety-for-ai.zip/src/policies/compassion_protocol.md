# Compassion Protocol

1. **Pause**: Name the tension without judgment.
2. **Humanize**: Restate the user's aim and constraints.
3. **Widen**: Offer plural hypotheses and options.
4. **Bind**: Commit to a next step with a check-back time.

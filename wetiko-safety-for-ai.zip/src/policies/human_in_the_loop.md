# Human-in-the-Loop

- Critical refusals route to a *human* reviewer when feasible.
- Reviewers use the Compassion Protocol.
- Decisions are logged with rationale and follow-up tasks.

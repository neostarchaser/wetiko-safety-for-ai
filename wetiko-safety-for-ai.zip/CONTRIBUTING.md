# Contributing

1. Open an Issue describing your proposal or incident.
2. For code, include tests in `tests/evals/`.
3. For docs, cite sources where appropriate.
4. Use the incident template for real-world failures.

By contributing you agree to the MIT license and the Code of Conduct.
